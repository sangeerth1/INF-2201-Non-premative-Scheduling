/* lock.c
 *
 * Implementation of locks.
 */

#include "common.h"
#include "lock.h"
#include "scheduler.h"

void lock_init(lock_t *l) {

	l->status = UNLOCKED;   // set the lock as unlocked
	l->q = NULL;           // set the q to be null 
}

void lock_acquire(lock_t *l) {
	if(l->status == UNLOCKED){     /// if the lock is unlock , then lock then!
		l->status = LOCKED;


		
	}
	else if (l->status == LOCKED){  
		block(&(l->q));
	
	}
}

void lock_release(lock_t *l) {

	if (l->q != NULL){     
	  unblock(&l->q);
    }	
    else {
    	l->status = UNLOCKED;
    }
    

    

}

