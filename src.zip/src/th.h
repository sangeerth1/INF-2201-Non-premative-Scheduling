/* th.h
 */

#ifndef TH_H
#define TH_H

// Prototypes
void clock_thread(void);

/* Threads to test locks */
void thread2(void);
void thread3(void);

/* More threads to test locks */
void mcpi_thread0(void);
void mcpi_thread1(void);
void mcpi_thread2(void);
void mcpi_thread3(void);

#endif
