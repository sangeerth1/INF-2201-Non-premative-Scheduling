/*  kernel.c
 */
#include "common.h"
#include "kernel.h"
#include "scheduler.h"
#include "th.h"
#include "util.h"

#define NUM 2


// Statically allocate some storage for the pcb's
pcb_t pcb[NUM_TOTAL];
// Ready queue and pointer to currently running process
pcb_t *current_running;


/* This is the entry point for the kernel.
 * - Initialize pcb entries
 * - set up stacks
 * - start first thread/process
 */
void pcb_init(void);

void _start(void) {
	/* Declare entry_point as pointer to pointer to function returning void
	 * ENTRY_POINT is defined in kernel h as (void(**)()0xf00)
	 */
	void (**entry_point)() = ENTRY_POINT;

	// load address of kernel_entry into memory location 0xf00
	*entry_point = kernel_entry;


	clear_screen(0, 0, 80, 25);
	
	set_block_to_check();

	




	
    current_running = &pcb[0];
    current_running->status = STATUS_READY;
   

 

__asm__(                                  ////  set up our stacks 

	"movl %0 ,%%esp;"
	"jmp  %1;"
	: /*no output */
	:"r" (current_running->stack1), "r"(current_running->address) //a  // stack1
	:


);


    

	
	



	while (1)
		;



}



/*  Helper function for kernel_entry, in entry.S. Does the actual work
 *  of executing the specified syscall.
 */
void kernel_entry_helper(int fn){ 
if (fn == SYSCALL_YIELD){       
    yield();
	}	
if (fn == SYSCALL_EXIT){
	exit();
	}
}



void threads_process( int i,int address);
void set_block_to_check(void)
{	
	 threads_process(0,0x5000);   /// define process 1 address and connect with threads_process
	 threads_process(1,0x7000);    /// define the process 2 address and connect with threads_process
	 threads_process(2,(int *)clock_thread);  // define the clock thread and connect with threads_process
	 threads_process(3,(int *)thread2);   // define the thread 2 and connect with threads_process
	 threads_process(4,(int *)thread3);   // define the thread 3 and connec with threads_process
	 threads_process(5,(int *)mcpi_thread0); // definee mcpi_thread 0 and connect with threads_process
	 threads_process(6,(int *)mcpi_thread1); // definee mcopi_thread 1 and connect with threads_process
	 threads_process(7,(int *)mcpi_thread2); // definee mcpi_thread 2 and connect with threads_process
	 threads_process(8,(int *)mcpi_thread3);

}




void threads_process( int i,int address)
{
		int x = 1; 

		if (i < 2){
			pcb[i].stack1 = STACK_MIN + (STACK_SIZE *i);    /// define user stack .. stack1 is user stack
			x = 0;
		}
		/// intializing all pcb entries 	
		pcb[i].address = address;   
		pcb[i].PID = i;  // value of pid 
		pcb[i].status = STATUS_FIRST_TIME;
		
		pcb[i].previous = &pcb[(i-1)% NUM_TOTAL];
		pcb[i].next = &pcb[(i+1) % NUM_TOTAL];
		pcb[i].stack2 = STACK_MAX - (STACK_SIZE*i);  // define kernel stack..  stack 2 is kernel stack
		pcb[i].is_thread = x; 
		

		
}

































 
	

