/* syslib.h
 */
#ifndef SYSLIB_H
#define SYSLIB_H

// Prototypes for exported system calls
void yield(void);
void exit(void);

#endif
