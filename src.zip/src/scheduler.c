/*  scheduler.c
 */
#include "common.h"
#include "kernel.h"
#include "scheduler.h"
#include "util.h"

// Call scheduler to run the 'next' process
void yield(void) {

	scheduler_entry();

		

}

/* The scheduler picks the next job to run, and removes blocked and exited
 * processes from the ready queue, before it calls dispatch to start the
 * picked process.
 */
void scheduler(void) {

    

	
	current_running = current_running->next;
	while ((current_running->status == STATUS_EXITED)||(current_running->status == STATUS_BLOCKED)){

 		 
		current_running = current_running->next;


 	}

	
	



	

	dispatch();	
}	
/* dispatch() does not restore gpr's it just pops down the kernel_stack,
 * and returns to whatever called scheduler (which happens to be scheduler_entry,
 * in entry.S).
 */

uint64_t time_to_measure = 0;



void dispatch(void) {
     uint64_t  end_time = get_timer();    // check time of end 


     print_int(0,0,end_time-time_to_measure);    /// to print and check the position of time_measure


    
	int stack = current_running->stack1;     ///  define our stack as current runing  user stack


	if (current_running->status == STATUS_FIRST_TIME){   // check if our current running as status exited

		current_running->status = STATUS_READY;          // seeting the status as ready    
	if(current_running->is_thread == TRUE){
		stack = current_running->stack2;
	}	
	  
	// using inline assembler to set up our stack pointer
	asm("movl %0,%%esp;"
		"finit;"
		"jmp %1;" 
		:
		: "r"(stack),"r"(current_running->address)
		:
	);
}

else{ 
	current_running->stack2 = current_running->stack2-4;

	asm("movl %0, %%esp;"
		"finit;" 
		"ret;"
		: 
		:"r"(current_running->stack2)
		:
		
	);	

	return;

}
}


/* Remove the current_running process from the linked list so it
 * will not be scheduled in the future
 */
void exit(void) {

	current_running->status = STATUS_EXITED;    // setting the status as exited 
	scheduler_entry();
}


/* 'q' is a pointer to the waiting list where current_running should be
 * inserted
 */
void block(pcb_t **q) {
 
	
	

	current_running->status = STATUS_BLOCKED;   ///  setting the status as blocked 



	   
	if((*q) == NULL){

		
	    (*q) = current_running;
		
	

}
else {

	current_running->block_next = (*q);


	current_running->block_previous = NULL;
	   

}  
	   
	
	
	
	yield();
	




   	

}


/* Must be called within a critical section.
 * Unblocks the first process in the waiting queue (q), (*q) points to the
 * last process.
 */
void unblock(pcb_t **q) {

	pcb_t *tmp = (*q);


	tmp->status = STATUS_READY;

	*q = (*q)->block_next;


	
	


	
}










